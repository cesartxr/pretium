# pretium
Introduction
------------

Pretium is a inference engine for expert systems using php language.
Expert systems is a computer systems that emulates the human hability to answer questions.
One special use os pretium is in financial analisys, where we could simulate the questions made by a financial assessor, colect the answers and produce a report. 

More information about expert systems could be found in https://en.wikipedia.org/wiki/Expert_system

Pretium is a implementation of my master degree thesis, in Military Engineering Institute in 1996, originaly written in C++, but the idea could be implemente in any language.

Anyone could use this software and if detect any problem or want to send sugestions my email is:

cesar.txr@outlook.com
